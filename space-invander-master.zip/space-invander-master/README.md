# space invander
developed a game space invader using c plus plus with memory management 

a game in which ship fires a bullet to kill different kind of enemies (with different strenth or attack)
a half code of the game was provided by teacher and challage is to complete that code and make game playable with colors and graphics
